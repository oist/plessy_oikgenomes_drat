# BreakpointsData 3.1.0

* Add and XZ-compress genome annotations in GFF format from
  `/bucket/LuscombeU/common/Breakpoints/Annotations`

# BreakpointsData 3.0.0

* Distribute the Oikopleura breakpoint set version 3.
