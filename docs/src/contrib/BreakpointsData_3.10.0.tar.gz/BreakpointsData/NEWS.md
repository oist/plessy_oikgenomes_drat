# BreakpointsData 3.10.0

* Added Nematode and Muntjak alignments.
* Recompressed other alignments.

# BreakpointsData 3.9.0

* Added human-mouse chr18 alignments.

# BreakpointsData 3.8.0

* Added Drosophila alignments from `/bucket/LuscombeU/common/Breakpoints/Alignments/Insects_pairwise_v3`.

# BreakpointsData 3.7.1

* Added N20 (Ciona intestinatlis) and N3 (tunicates) Orthogroup files.

# BreakpointsData 3.7.0

* Added Ciona alignments and annotations.
* `find inst/extdata/ -type f | xargs md5sum | grep -v md5sum > inst/extdata/md5sums`

# BreakpointsData 3.6.1

* Added dNdS scores.
  Original location: `/bucket/LuscombeU/common/Breakpoints/dNdS/v2.0.0/genewise_oikopleura.extended.txt`.

# BreakpointsData 3.6.0

* Update phylogenetic hierarchical orthogroups (note that file name changed).
  Original location: `/bucket/LuscombeU/common/Breakpoints/Orthologues/selTun+Apps+Amph+Vert_lp_100clstr_blast/OrthoFinder/Results_Oct07/Phylogenetic_Hierarchical_Orthogroups/N19.tsv`.

# BreakpointsData 3.5.0

* Add Norway genome repeat annotation from `/bucket/LuscombeU/common/Breakpoints/Annotations`.
* Update Barcelona genome repeat annotation (correct chromosome names).

# BreakpointsData 3.4.1

* Add other genomes repeat annotation from `/bucket/LuscombeU/common/Breakpoints/Annotations`.

# BreakpointsData 3.4.1

* Add repeat annotation from `/bucket/LuscombeU/aleksandrabliznina/run_repeat_masking/OKI2018_I69/OKI2018_I69.repeats.gff`.

# BreakpointsData 3.4.0

* Add the `N6` file from `/bucket/LuscombeU/common/Breakpoints/Orthologues/selectedTunicates+Amph+vertebrates_lp_100clstr_blast/OrthoFinder/Results_Sep07/Phylogenetic_Hierarchical_Orthogroups/N6.tsv`.

# BreakpointsData 3.3.0

* Correct short / long boundary on Chr1 and PAR for Osaka

# BreakpointsData 3.2.0

* Change compression from XZ to GZ because rtracklayer can not
  load them.

* Add annotation on long / short arms in GFF format to the
  `Annotations` folder.

# BreakpointsData 3.1.0

* Add and XZ-compress genome annotations in GFF format from
  `/bucket/LuscombeU/common/Breakpoints/Annotations`

# BreakpointsData 3.0.0

* Distribute the Oikopleura breakpoint set version 3.
