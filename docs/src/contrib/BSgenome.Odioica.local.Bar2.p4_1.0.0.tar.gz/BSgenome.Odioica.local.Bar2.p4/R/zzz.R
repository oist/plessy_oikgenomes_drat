###
###

.pkgname <- "BSgenome.Odioica.local.Bar2.p4"

.seqnames <- c('Chr1', 'Chr2', 'HiC_scaffold_6_pilon', 'HiC_scaffold_7_pilon', 'HiC_scaffold_8_pilon', 'HiC_scaffold_9_pilon', 'HiC_scaffold_10_pilon', 'HiC_scaffold_11_pilon', 'HiC_scaffold_12_pilon', 'HiC_scaffold_13_pilon', 'HiC_scaffold_14_pilon', 'HiC_scaffold_15_pilon', 'HiC_scaffold_16_pilon', 'HiC_scaffold_17_pilon', 'HiC_scaffold_18_pilon', 'HiC_scaffold_19_pilon', 'HiC_scaffold_20_pilon', 'HiC_scaffold_21_pilon', 'HiC_scaffold_22_pilon', 'HiC_scaffold_23_pilon', 'HiC_scaffold_24_pilon', 'HiC_scaffold_25_pilon', 'HiC_scaffold_26_pilon', 'HiC_scaffold_27_pilon', 'HiC_scaffold_28_pilon', 'HiC_scaffold_29_pilon', 'HiC_scaffold_30_pilon', 'HiC_scaffold_31_pilon', 'HiC_scaffold_32_pilon', 'HiC_scaffold_33_pilon', 'HiC_scaffold_34_pilon', 'HiC_scaffold_35_pilon', 'HiC_scaffold_36_pilon', 'HiC_scaffold_37_pilon', 'HiC_scaffold_38_pilon', 'HiC_scaffold_39_pilon', 'HiC_scaffold_40_pilon', 'HiC_scaffold_41_pilon', 'HiC_scaffold_42_pilon', 'HiC_scaffold_43_pilon', 'HiC_scaffold_44_pilon', 'HiC_scaffold_45_pilon', 'HiC_scaffold_46_pilon', 'HiC_scaffold_47_pilon', 'HiC_scaffold_48_pilon', 'HiC_scaffold_49_pilon', 'HiC_scaffold_50_pilon', 'HiC_scaffold_51_pilon', 'HiC_scaffold_52_pilon', 'HiC_scaffold_53_pilon', 'HiC_scaffold_54_pilon', 'HiC_scaffold_55_pilon', 'HiC_scaffold_56_pilon', 'HiC_scaffold_57_pilon', 'HiC_scaffold_58_pilon', 'HiC_scaffold_59_pilon', 'HiC_scaffold_60_pilon', 'HiC_scaffold_61_pilon', 'HiC_scaffold_62_pilon', 'HiC_scaffold_63_pilon', 'HiC_scaffold_64_pilon', 'HiC_scaffold_65_pilon', 'HiC_scaffold_66_pilon', 'HiC_scaffold_67_pilon', 'HiC_scaffold_68_pilon', 'PAR', 'XSR', 'YSR')

.circ_seqs <- c()

.mseqnames <- NULL

.onLoad <- function(libname, pkgname)
{
    if (pkgname != .pkgname)
        stop("package name (", pkgname, ") is not ",
             "the expected name (", .pkgname, ")")
    extdata_dirpath <- system.file("extdata", package=pkgname,
                                   lib.loc=libname, mustWork=TRUE)

    ## Make and export BSgenome object.
    bsgenome <- BSgenome(
        organism="Oikopleura dioica",
        common_name="Oikopleura dioica",
        genome="Bar2_p4",
        provider="Luscombe Unit, OIST",
        release_date="2021-08-31",
        source_url="Not available for the download at the moment",
        seqnames=.seqnames,
        circ_seqs=.circ_seqs,
        mseqnames=.mseqnames,
        seqs_pkgname=pkgname,
        seqs_dirpath=extdata_dirpath
    )

    ns <- asNamespace(pkgname)

    objname <- pkgname
    assign(objname, bsgenome, envir=ns)
    namespaceExport(ns, objname)

    old_objname <- "Bar2_p4"
    assign(old_objname, bsgenome, envir=ns)
    namespaceExport(ns, old_objname)
}

