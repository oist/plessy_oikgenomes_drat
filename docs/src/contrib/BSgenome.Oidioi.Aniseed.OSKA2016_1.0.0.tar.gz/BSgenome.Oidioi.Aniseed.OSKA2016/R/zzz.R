###
###

.pkgname <- "BSgenome.Oidioi.Aniseed.OSKA2016"

.seqnames <- gtools::mixedsort(sub('.fa', '', list.files('OSKA2016', pattern = '*.fa')))

.circ_seqs <- c()

.mseqnames <- NULL

.onLoad <- function(libname, pkgname)
{
    if (pkgname != .pkgname)
        stop("package name (", pkgname, ") is not ",
             "the expected name (", .pkgname, ")")
    extdata_dirpath <- system.file("extdata", package=pkgname,
                                   lib.loc=libname, mustWork=TRUE)

    ## Make and export BSgenome object.
    bsgenome <- BSgenome(
        organism="Oikopleura dioica",
        common_name="North Pacific oik",
        genome="OSKA2016",
        provider="Aniseed",
        release_date="2019-04-16",
        source_url="https://www.aniseed.cnrs.fr/aniseed/download/?file=data%2Foidioi%2FOidioi_genome_fasta_gff3.zip",
        seqnames=.seqnames,
        circ_seqs=.circ_seqs,
        mseqnames=.mseqnames,
        seqs_pkgname=pkgname,
        seqs_dirpath=extdata_dirpath
    )

    ns <- asNamespace(pkgname)

    objname <- pkgname
    assign(objname, bsgenome, envir=ns)
    namespaceExport(ns, objname)

    old_objname <- "Oidioi"
    assign(old_objname, bsgenome, envir=ns)
    namespaceExport(ns, old_objname)
}

