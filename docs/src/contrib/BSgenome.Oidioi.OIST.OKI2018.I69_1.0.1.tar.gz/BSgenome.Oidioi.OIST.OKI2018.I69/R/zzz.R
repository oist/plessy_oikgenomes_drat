###
###

.pkgname <- "BSgenome.Oidioi.OIST.OKI2018.I69"

.seqnames <- gtools::mixedsort(sub('.fa', '', list.files('OKI2018_I69', pattern = '*.fa')))

.circ_seqs <- c()

.mseqnames <- NULL

.onLoad <- function(libname, pkgname)
{
    if (pkgname != .pkgname)
        stop("package name (", pkgname, ") is not ",
             "the expected name (", .pkgname, ")")
    extdata_dirpath <- system.file("extdata", package=pkgname,
                                   lib.loc=libname, mustWork=TRUE)

    ## Make and export BSgenome object.
    bsgenome <- BSgenome(
        organism="Oikopleura dioica",
        common_name="Okinawan oik",
        genome="OKI2018.I69",
        provider="OIST",
        release_date="12-Oct-2020",
        source_url="https://zenodo.org/record/4023777",
        seqnames=.seqnames,
        circ_seqs=.circ_seqs,
        mseqnames=.mseqnames,
        seqs_pkgname=pkgname,
        seqs_dirpath=extdata_dirpath
    )

    ns <- asNamespace(pkgname)

    objname <- pkgname
    assign(objname, bsgenome, envir=ns)
    namespaceExport(ns, objname)

    old_objname <- "Oidioi"
    assign(old_objname, bsgenome, envir=ns)
    namespaceExport(ns, old_objname)
}

