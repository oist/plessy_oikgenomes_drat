###
###

.pkgname <- "BSgenome.Oidioi.OIST.KUM.M3.7f"

.seqnames <- c('contig_2_1', 'contig_3_1', 'contig_4_1', 'contig_6_1', 'contig_7_1', 'contig_9_1', 'contig_10_1', 'contig_11_1', 'contig_12_1', 'contig_13_1', 'contig_14_1', 'contig_15_1', 'contig_16_1', 'contig_17_1', 'contig_18_1', 'contig_22_1', 'contig_23_1', 'contig_24_1', 'contig_26_1', 'contig_27_1', 'contig_28_1', 'contig_29_1', 'contig_33_1', 'contig_34_1', 'contig_36_1', 'contig_37_1', 'contig_38_1', 'contig_41_1', 'contig_42_1', 'contig_43_1', 'contig_44_1', 'contig_45_1', 'contig_47_1', 'contig_49_1', 'contig_51_1', 'contig_55_1', 'contig_57_1', 'contig_61_1', 'contig_63_1', 'contig_64_1', 'contig_66_1', 'contig_70_1', 'contig_72_1', 'contig_78_1', 'contig_79_1', 'contig_81_1', 'contig_82_1', 'contig_83_1', 'contig_85_1', 'contig_86_1', 'contig_87_1', 'contig_88_1', 'contig_89_1', 'contig_90_1', 'contig_91_1')

.circ_seqs <- c()

.mseqnames <- NULL

.onLoad <- function(libname, pkgname)
{
    if (pkgname != .pkgname)
        stop("package name (", pkgname, ") is not ",
             "the expected name (", .pkgname, ")")
    extdata_dirpath <- system.file("extdata", package=pkgname,
                                   lib.loc=libname, mustWork=TRUE)

    ## Make and export BSgenome object.
    bsgenome <- BSgenome(
        organism="Oikopleura dioica",
        common_name="Okinawan oik",
        genome="KUM.M3.7f",
        provider="OIST",
        release_date="2021-08-30",
        source_url="Not available for the download at the moment",
        seqnames=.seqnames,
        circ_seqs=.circ_seqs,
        mseqnames=.mseqnames,
        seqs_pkgname=pkgname,
        seqs_dirpath=extdata_dirpath
    )

    ns <- asNamespace(pkgname)

    objname <- pkgname
    assign(objname, bsgenome, envir=ns)
    namespaceExport(ns, objname)

    old_objname <- "Oidioi"
    assign(old_objname, bsgenome, envir=ns)
    namespaceExport(ns, old_objname)
}

