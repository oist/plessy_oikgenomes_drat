###
###

.pkgname <- "BSgenome.Oidioi.genoscope.OdB3"

.seqnames <- gtools::mixedsort(sub('.fa', '', list.files('Odioica_reference_v3.0', pattern = '*.fa')))

.circ_seqs <- c()

.mseqnames <- NULL

.onLoad <- function(libname, pkgname)
{
    if (pkgname != .pkgname)
        stop("package name (", pkgname, ") is not ",
             "the expected name (", .pkgname, ")")
    extdata_dirpath <- system.file("extdata", package=pkgname,
                                   lib.loc=libname, mustWork=TRUE)

    ## Make and export BSgenome object.
    bsgenome <- BSgenome(
        organism="Oikopleura dioica",
        common_name="Atlantic oik",
        genome="OdB3",
        provider="Génoscope",
        release_date="18-Sep-2006",
        source_url="http://www.genoscope.cns.fr/externe/Download/Projets/Projet_HG/data/assembly/unmasked/Odioica_reference_v3.0.fa",
        seqnames=.seqnames,
        circ_seqs=.circ_seqs,
        mseqnames=.mseqnames,
        seqs_pkgname=pkgname,
        seqs_dirpath=extdata_dirpath
    )

    ns <- asNamespace(pkgname)

    objname <- pkgname
    assign(objname, bsgenome, envir=ns)
    namespaceExport(ns, objname)

    old_objname <- "Oidioi"
    assign(old_objname, bsgenome, envir=ns)
    namespaceExport(ns, old_objname)
}

