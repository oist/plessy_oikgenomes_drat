###
###

.pkgname <- "BSgenome.Odioica.local.AOM.5"

.seqnames <- c('contig_1_1', 'contig_2_1', 'contig_3_1', 'contig_4_1', 'contig_5_1', 'contig_8_1', 'contig_10_1', 'contig_12_1', 'contig_14_1', 'contig_15_1', 'contig_19_1', 'contig_20_1', 'contig_21_1', 'contig_22_1', 'contig_23_1', 'contig_24_1', 'contig_27_1', 'contig_29_1', 'contig_31_1', 'contig_32_1', 'contig_34_1', 'contig_36_1', 'contig_38_1', 'contig_39_1', 'contig_40_1', 'contig_41_1', 'contig_42_1', 'contig_44_1', 'contig_45_1', 'contig_46_1', 'contig_47_1', 'contig_48_1', 'contig_49_1')

.circ_seqs <- c()

.mseqnames <- NULL

.onLoad <- function(libname, pkgname)
{
    if (pkgname != .pkgname)
        stop("package name (", pkgname, ") is not ",
             "the expected name (", .pkgname, ")")
    extdata_dirpath <- system.file("extdata", package=pkgname,
                                   lib.loc=libname, mustWork=TRUE)

    ## Make and export BSgenome object.
    bsgenome <- BSgenome(
        organism="Oikopleura dioica",
        common_name="Oikopleura dioica",
        genome="AOM-5-5f",
        provider="Luscombe Unit, OIST",
        release_date="2021-08-31",
        source_url="Not available for the download at the moment",
        seqnames=.seqnames,
        circ_seqs=.circ_seqs,
        mseqnames=.mseqnames,
        seqs_pkgname=pkgname,
        seqs_dirpath=extdata_dirpath
    )

    ns <- asNamespace(pkgname)

    objname <- pkgname
    assign(objname, bsgenome, envir=ns)
    namespaceExport(ns, objname)

    old_objname <- "AOM_5"
    assign(old_objname, bsgenome, envir=ns)
    namespaceExport(ns, old_objname)
}

