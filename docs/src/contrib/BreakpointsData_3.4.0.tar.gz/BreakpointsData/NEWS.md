# BreakpointsData 3.4.0

* Add the `N6` file from `/bucket/LuscombeU/common/Breakpoints/Orthologues/selectedTunicates+Amph+vertebrates_lp_100clstr_blast/OrthoFinder/Results_Sep07/Phylogenetic_Hierarchical_Orthogroups/N6.tsv`.

# BreakpointsData 3.3.0

* Correct short / long boundary on Chr1 and PAR for Osaka

# BreakpointsData 3.2.0

* Change compression from XZ to GZ because rtracklayer can not
  load them.

* Add annotation on long / short arms in GFF format to the
  `Annotations` folder.

# BreakpointsData 3.1.0

* Add and XZ-compress genome annotations in GFF format from
  `/bucket/LuscombeU/common/Breakpoints/Annotations`

# BreakpointsData 3.0.0

* Distribute the Oikopleura breakpoint set version 3.
